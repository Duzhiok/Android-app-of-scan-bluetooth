package com.example.zoro.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class second extends AppCompatActivity {
    TextView textView;
    EditText editText;
    private static final String DB_URL = "jdbc:mysql://10.162.15.229:3306/database1";
    private static final String USER = "root";
    private static final String PASS = "Cc192837465";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText3);
    }

    public void btnConn(View view) {
        Send objSend = new Send();
        objSend.execute("");
    }

    private class Send extends AsyncTask<String, String, String> {
        String msg = "";
        String text = editText.getText().toString();

        @Override
        protected void onPreExecute() {
            textView.setText("please wait inserting data");
        }

        @Override
        protected String doInBackground(String... Strings) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                if (conn == null)
                {
                    msg = "connection goes wrong";
                } else
                    {
                    String query = "INSERT INTO (X) VALUES('" + text + "')";
                    Statement stmt = conn.createStatement();
                    stmt.executeUpdate(query);
                    msg = "insert successfully";
                    }
                conn.close();
            } catch (Exception e)
            {
            msg = "connection goes wrong";
            e.printStackTrace();
            }
                    return msg;
    }

    @Override
    protected void onPostExecute(String msg)
    {
        textView.setText(msg);
    }
}

}
