package com.example.zoro.myapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.zoro.myapp.R;
import com.example.zoro.myapp.second;

public class LoginActivity extends AppCompatActivity {

    private EditText ID;
    private EditText Password;
    private Button Login;
    private int counter=5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ID = (EditText) findViewById(R.id.editText);
        Password = (EditText) findViewById(R.id.editText2);
        Login = (Button) findViewById(R.id.button1);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ID.getText().toString().equals("123") && Password.getText().toString().equals("123")) {

                    Intent intent = new Intent(LoginActivity.this, Bluetooth.class);
                    startActivity(intent);
                } else {
                    counter--;
                    if (counter==0)
                        Login.setEnabled(false);
                }

            }
        } );}}

